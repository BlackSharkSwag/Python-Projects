isAlive = True
choiceOne = input("You walk into a darkly light mansion, you find a lit CANDLE and LIGHTER.\nWhich one do you want "
                  "pick up? ")


def alive_or_nah(alive):
    if not alive:
        print("\nYou died!!!")
    else: 
        print("\nYou survived! Congrats!!")


# start 1
if choiceOne.lower() == 'candle':
    print("\nYou pick up the candle and notice a shady figure rushing towards you from a dark corner in the mansion.")
    choiceTwo = input("Below your feet you see a HATCHET and a wooden STAKE. \nWhich one do you want to pick up? ")

    # start 2
    if choiceTwo.lower() == 'hatchet':
        print("\nAs you ready yourself, the figure emerges and appears to be a 🧛‍♂️ vampire.\nAs the 🧛‍♂️ vampire goes to bite "
              "you, you slice at it with the hatchet")
        choiceThree = input("Do you swing for its HEAD or STOMACH? ")
        
        # start 3
        if choiceThree.lower() == 'head':
            print("\nAs you swing your axe at the 🧛‍♂️ vampires head you make a direct hit taking its head clean off.\nIt "
                  "appears to be dead.")
            choiceFour = input("As the head rolls to the ground you hear other footsteps come rushing towards "
                               "you.\nDo you RUN or FIGHT? ")

            # start 4
            if choiceFour.lower() == "fight":
                print("\nAs you stand your ground, a horde of 🧛‍♂️ vampires swarm the room from every direction.")
                isAlive = False

            else:
                print("\nAs the noise get louder you dash like a bolt of lightning towards the entry way.\nAs you "
                      "dash by shadowy figures closing in, you hear a voice from outside yell dive!\nTaking their "
                      "advice you dive out the entryway, only to see a figure detonate dynamite causing the mansion "
                      "to explode.\nYou both hide in a cave through the night, the sunlight kills the 🧛‍♂️ vampires. ")

            # end 4

        # stomach
        else:
            print("\nAs you swing your axe at the 🧛‍♂️ vampires stomach you hit it, you see some blood on the blade but he "
                  "seems to be unfazed. You are tackled. ")
            isAlive = False

        # end 3

    else:
        choiceThree = input("\nAs you ready yourself, the figure emerges showing 🧛‍♂️ vampire like fangs ready to bite "
                            "you.\nYou stab the 🧛‍♂️ vampire in the heart killing it.\nYou see other 🧛‍♂️ vampires begin to "
                            "emerge from the shadows to rush at you. \nDo you RUN or FIGHT? ")
        if choiceThree.lower() == 'run':
            print("\nAs the sound of a horde of 🧛‍♂️ vampires running at you gets louder.\nYou dash like a bolt of "
                  "lightning towards the entry way.\nAs you dash by shadowy figures closin in, you hear a voice from "
                  "outside yell dive!\nTaking their advice you dive out the frontway, only to see a figure detonate "
                  "dynamite causing the mansion to explode.\nYou both hide in a cave through the night, the sunlight "
                  "kills the 🧛‍♂️ vampires.")

        else:
            print("\nAs you stand your ground, you feel your body become frozen with fear from the sight of the "
                  "figure that emerges out of the dark.")
            isAlive = False
        
    # end 2

else:
    choiceTwo = input("\nYou lit the lighter and can barely see anything, you feel a rush of wind and the sound of "
                      "footsteps coming from somewhere.\nDo you try and HIDE, RUN or YELL? ")
    if choiceTwo.lower() == 'hide':
        choiceThree = input("\nYou sense the presence of a 👻 spirit, it seems upset about something.\nIt keeps yelling "
                            "'Amulet! Where is it!?!' You begin to notice something shiny under the nightstand you "
                            "are hiding behind.\nDo you GRAB it or RUN for the door? ")
        if choiceThree.lower() == 'grab':
            choiceFour = input("\nThe object appears to resemble an 'Amulet', do you KEEP it or SHOW it to the angry "
                               "👻 ghost? ")
            if choiceFour.lower() == 'show':
                print("\nYou stand up and speak to get the 👻 ghosts attention. The 👻 ghost is surprised by your sudden "
                      "appearance, and rushes over to you with vengeance!\nYou hold up the Amulet in efforts to "
                      "distract it.\nIt stops at the sight of the object.\nIt grabs it from your hands...\nIt looks "
                      "at you with tears in its eyes, and says thank you while slowly disappearing.")
                choiceFive = input("\nYou feel a deep calm come over you, the house then begins to be sucked down "
                                   "into a portal.\nDo you STAY or RUN outside to escape from the collapsing mansion? ")
                if choiceFive.lower() == 'run':
                    print("\nAs the floor is being sucked into an unknown portal, you run and leap out the door to "
                          "safety.")

                else:
                    print("\nYou and the mansion vanish. ")
                    isAlive = False

            else:
                print("\nWhen has greed ever done anything good for somebody? A portal from the Amulet sucks you into "
                      "it. Never to be seen again! ")
                isAlive = False
        else:
            print("\nYou trip and fall...")
            isAlive = False

    elif choiceTwo.lower() == 'run':
        print("\nDid you learn nothing from Casper the Friendly Ghost!?")
        choiceThree = input("\nThe ghost chases after you! Do you continue to RUN for the door or GRAB the vacuum next "
                            "to the desk? ")
        if choiceThree.lower() == 'run':
            print("\nYou manage to make it out the door before the ghost catches you, it appears to be locked in the "
                  "mansion by some magic barrier. ")
        else:
            print("As you grab the vacuum and turn it on to suck up the ghost. The vacuum turns to you with a mind of "
                  "its own. It sucks you up as its dinner! ")
            isAlive = False
    else:
        print("\nYour yelling draws the attention of other figures and you feel the air escape from your lungs. ")
        isAlive = False
# end 1

alive_or_nah(isAlive)
