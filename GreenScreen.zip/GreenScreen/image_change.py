from PIL import Image

info = True

while (info == True):
    image_input = ''

    print("options: 'earth.jpg', 'desert.jpg', 'beach.jpg', 'field.jpg', 'forest.jpg'")

    image_input = input("What background image do you want to use? ")

    if (image_input.lower() == 'earth.jpg' or image_input.lower() == 'beach.jpg' or image_input.lower() == 'desert.jpg' or image_input.lower() == 'forest.jpg' or image_input.lower() == 'field.jpg'):
        info = False
    else: 
        print("not a valid option.")

image_green = Image.open("penguin.jpg")
image_beach = Image.open(image_input)
image_new = Image.new("RGB", image_beach.size)

width, height = image_green.size

pixels_beach = image_beach.load()
pixels_green = image_green.load()
pixels_new = image_new.load()

for x in range(0, width):
    for y in range (0, height):
        (r, g, b) = pixels_green[x,y]  #prop

        if(r <=117 and g >=175 and b <=100):
            pixels_new[x,y] = pixels_beach[x,y] #background
        else:
            pixels_new[x,y] = (r, g, b)


image_new.show()
image_new.save("green_screen_image.jpg")
