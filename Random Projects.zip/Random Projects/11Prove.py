"""
Shane C Cook
10-18-21
"""
min_life = 100000
min_name = None
max_life = -100000
max_name = None

#year_choice = input(f'Please enter the year of interest')
#country_choice

with open("life-expectancy.csv") as file:
    for line in file:
        clean_line = line.strip()
        parts = clean_line.split(",")

        name = parts[0]
        code = parts[1]
        year = parts[2]
        life = float(parts[3])

        if  life > max_life:
            max_life = life
            max_name = name
        elif life < min_life:
            min_life = life
            min_name = name

print(f'The country with the highest life expectancy is {max_name} with a life expectancy of {max_life} years.')