import math

#Square
length = float(input("\nEnter a length: "))
area_of_square = length ** 2
rectangle_width = float(input("Width for a rectangle: "))

#rectangle_length = float(input("What is the length of the rectangle? "))
#circle_radius = float(input("What is the radius of the circle? "))
area_of_circle = math.pi * (length ** 2)
area_of_rectangle = length * rectangle_width
volume_of_cube = length ** 3
volume_of_sphere = (4 / 3) * math.pi * (length ** 3)

print(f"\nThr area of a square is: {area_of_square:.2f}")
print(f"The area of a rectangle is: {area_of_rectangle:.2f}")
print(f"The area of a circle is: {area_of_circle:.2f}")
print(f"The volume of a cube is: {volume_of_cube:.2f}")
print(f"The volume of a sphere is: {volume_of_sphere:.2f}")
