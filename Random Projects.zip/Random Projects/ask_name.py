name_first = input(f"What is your first name? ")
name_second = input(f"What is your last name? ")

print(f"Your name is {name_second}, {name_first} {name_second}.")