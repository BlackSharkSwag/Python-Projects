shopping_cart = []
item_price = []


while True:
    print("\nPlease select one of the following: ")
    print("1. Add item")
    print("2. View cart")
    print("3. Remove item")
    print("4. Compute total")
    print("5. Quit")

    action = input("\nPlease enter an action: ")

    if action == '1':
        item = input("What item would you like to add? ")
        price = input(f"What is the price of '{item}'? ")

        shopping_cart.append(item)
        item_price.append(float(price))

    if action == '2':
        print("\nThe contents of the shopping cart are: ")

        for i in range(len(shopping_cart)):
            print("%d. %-10s - $ %-7.2f" % (i+1,shopping_cart[i],item_price[i]))

    if action == '3':
        i = int(input("Which item would you like to remove? ")) - 1
        length = len(shopping_cart) - 1

        if i < 0 or i > length:
            print("\nSorry that is not a valid number.")
        else:
            shopping_cart.pop(i)
            item_price.pop(i)

    if action == '4':
        print(f"The total price of the items in the shopping cart is ${sum(item_price):.2f}")

    if action.lower() == 'quit' or action == '5':
        print("\nThank you. Goodbye.")
        exit()