grade = int(input("What is your grade percent? "))

if grade >= 90:
    letter = 'A'
elif grade >= 80:
    letter = 'B'
elif grade >= 70:
    letter = 'C'
elif grade >= 60:
    letter = 'D'
else:
    letter = 'F'


last_digit = grade % 10

if last_digit >= 7:
    symbol = '+'
elif last_digit < 3:
    symbol = '-'
else:
    symbol = ''

if grade >= 93:
    symbol = ''

if letter == 'F':
    symbol = ''
    

print(f"Your grade is {letter}{symbol}")

if letter == 'F':
    print("Sorry, you failed the class.")
else:
    print("Congrats, you passed the class!")