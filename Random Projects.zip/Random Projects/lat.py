import math

min_life = 100000
min_name = None
max_life = -100000
max_name = None

#year_choice = input(f'Please enter the year of interest')
#country_choice

with open("lat.csv") as file:
    for line in file:
        clean_line = line.strip()
        parts = clean_line.split(",")

        lat = parts[1]
        log = parts[2]

degrees_lat = float(lat)
degrees_lat = math.floor(degrees_lat)

degrees_log = float(log)
degrees_log = math.ceil(degrees_log)

print(f"degrees lat: {degrees_lat}")
print(f"degrees log: {degrees_log}")
