# Prompts
child_meal = float(input("\nWhat is the price of a child's meal? "))
adult_meal = float(input("What is the price of an adult's meal? "))
child_count = float(input("How many children are there? "))
adult_count = float(input("How many adults are there? "))
tax_rate = float(input("What is the sales tax rate? "))

#Calculations
meal_subtotal = float((child_meal * child_count) + (adult_count * adult_meal))
sales_tax = float((meal_subtotal * tax_rate) / 100)
total = float(sales_tax + meal_subtotal)

#Print values
print(f"\nSubtotal: ${meal_subtotal:.2f}")
print(f"Sales Tax: ${sales_tax:.2f}")
print(f"Total: ${total:.2f}")

#Prompt for payment account, then calculate and show change
payment_amount = float(input("\nWhat is the payment amount? "))

#User input handling
while(True):
    if float((payment_amount < total)):
        print ("Error, you cant pay less than the total. Try again.")
        payment_amount = 0
        payment_amount = float(input("\nWhat is the payment amount? "))
    else:
        change_amount = payment_amount - total
        print(f"Change: ${change_amount:.2f}\n")
        break