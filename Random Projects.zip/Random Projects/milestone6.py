answer = input("Enter the year of interest: ")
country = input("Enter a country of interest: ")
highest_number = 0
lowest_number = 999999
count = 0
count2 = 0
sum = 0
sum2 = 0
average = 0
input_max = 0
input_min = 999999
country_max = 0
country_min = 999999

with open("life-expectancy.csv") as file:
    for line in file:
        clean_line = line.strip()
        parts = clean_line.split(",")

        country_index = parts[0]
        code = parts[1]
        yearly = parts[2]
        life = float(parts[3])

        if country_index.lower() == country.lower():
            sum2 += float(parts[3])
            count2 += 1
            if life > country_max:
                country_max = life
                country_index_max = parts[0]

            if life < country_min:
                country_min = life
                country_index_min = parts[0]

        if yearly == answer:
            sum += float(parts[3])
            count += 1
            if life > input_max:
                input_max = life
                entity_max = parts[0]

            if life < input_min:
                input_min = life
                entity_min = parts[0]

        if life > highest_number:
            highest_number = life
            entity = parts[0]
            year = parts[2]

        if life < lowest_number:
            lowest_number = life
            entity_lower = parts[0]
            year_lower = parts[2]

average = sum / count
total = sum2 / count2

print(f"\nThe overall max life expectancy is: {highest_number} from {entity} in {year}")
print(f"The overall min life expectancy is: {lowest_number} from {entity_lower} in {year_lower}")

print(f"\nFor the year {answer}:")
print(f"The average life expectancy across all countries was {average:.2f}")
print(f"The max life expectancy was in {entity_max} with {input_max}")
print(f"The min life expectancy was in {entity_min} with {input_min}")

print(f"\nFor the country {country}")
print(f"The average life expectancy across all countries was {total:.2f}")
print(f"The max life expectancy was in {country_index_max} with {country_max}")
print(f"The min life expectancy was in {country_index_min} with {country_min}")