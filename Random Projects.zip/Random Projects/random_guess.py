import random

keep_playing = True


while keep_playing == True:
    magic_number = random.randint(1,10)
    guess = 0
    guess_count = 0

    while guess != magic_number:
        guess = int(input("What is the magic number? "))
        guess_count = guess_count + 1

        if guess < magic_number:
            print("Higher")
        elif guess > magic_number:
            print("Lower")
        else:
            print("You got it!")

    print(f"You guessed the number in {guess_count} guesses")

    continueGame = input("Do you want to play again? (yes/no) ")

    if continueGame.lower() == 'no':
        keep_playing = False
    
print("Thank you for playing.")
