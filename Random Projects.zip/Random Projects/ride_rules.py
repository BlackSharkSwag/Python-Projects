first_age = int(input("What is the age of the first rider? "))
first_height = int(input("What is the height of the first rider? "))
status = False

if (first_age >= 12 and first_age <= 17):
    passport = input("Do you have a golden passport (yes/no)? ")
    if (passport.lower() == 'yes'):
        first_age = 18
        status = True

if (first_height < 36):
    status = False
else:
    another_rider = input ("Is there a second rider (yes/no)? ")
    if (another_rider.lower() == 'yes'):
        second_age = int(input("What is the age of the second rider? "))
        second_height = int(input("What is the height of the second rider? "))

        if (second_height < 36):
            status = False
        else:
            if ((second_age >= 12 and second_age <= 17) and first_age < 18):
                passport = input("Do you have a golden passport (yes/no)? ")
                if (passport.lower() == 'yes'):
                    second_age = 18
                    status = True

            if (second_age >= 18 or first_age >= 18):
                status = True

        if (status == False):
            if ((first_age >= 12 and second_age >= 12) and (first_height >=52 and second_height >= 52)):
                status = True
            elif ((first_age >= 14 and second_age >= 16) or (first_age >= 16 and second_age >= 14)):
                status = True
            else:
                status = False
    else:
        if(first_age >= 18):
            status = True


if (status):
    print("Welcome to the ride. Please be safe and have fun!")
else:
    print("Sorry, you may not ride.")
