numbers = []
number = 1
sum = 0
smallest_number = 99999

print("Enter a list of numbers, type 0 when finished.")

while number != 0:
    number = int(input("Enter number: "))

    if number != 0:
        numbers.append(number)


for number in numbers:
    sum += number

count = len(numbers)
average = sum / count

largest_number = 0

for number in numbers:
    if number > largest_number:
        largest_number = number



for number in numbers:
    if number > 0 and number < smallest_number:
        smallest_number = number


sorted_list = sorted(numbers)

print(f"The sum is: {sum}")
print(f"The average is: {average}")
print(f"The largest number is {largest_number}")
print(f"The smallest positive number is: {smallest_number}")
print("The sorted list is: ")
for number in sorted_list:
    print(number)