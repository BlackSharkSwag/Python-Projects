def binary_search(l, item):
  low = 0
  high = len(l) - 1
  mid = 0

  while low < high:
    if l[mid] == item:
      return mid
    if (mid == low or mid == high) and low == high - 1:
      return -1
    if item > l[mid]:
      low = mid
    else:
      high = mid
    mid = (low + high) // 2

  return -1

def linear_search(l, item):
  for i in range(len(l)):
    if item == l[i]:
      return i
  return -1

def random_search(l, item):
  indexes = list(range(len(l)))
  random.shuffle(indexes)
  for i in indexes:
    if item == l[i]:
      return i
  return -1

l = list(range(10000000))
y = 2572004

import random, time

start = time.time()
print(f"Value is found at Index: {binary_search(l,y)}")
end = time.time()
print(f"Execution took {end - start} seconds for binary.\n")

start = time.time()
print(f"Value is found at Index: {linear_search(l,y)}")
end = time.time()
print(f"Execution took {end - start} seconds for linear.\n")

start = time.time()
print(f"Value is found at Index: {random_search(l, y)}")
end = time.time()
print(f"Execution took {end - start} seconds for random.\n")