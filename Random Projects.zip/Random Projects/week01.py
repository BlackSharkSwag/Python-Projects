food = input("What is your favorite food? ")
color = input("Please type your favorite color: ")
print(f"Your favorite color is \'{color}\', and your favorite food is \'{food}\'!")
