temp = float(input("\nWhat is the temperature? "))
f_or_c = input("Fahrenheit or Celsius (F/C)? ")

def calculate_f(temperature):
    temp = (temperature * 1.8000) + 32
    return temp

def calculate_wind_chill(temperature):
    windchill = {}
    for ws in range(5,61,5):
        windchill[ws] = 35.74 + ((0.6215 * temperature) - (35.75 * (ws**0.16))) + ((0.4275 * temperature)*(ws**0.16))
    return windchill

def print_f(dictionary):
    value = temp
    if f_or_c.lower() == 'c':
        value = calculate_f(value)
    for key in dictionary.keys():
        print(f"At temperature {value}F, and wind speed {key}, the windchill is: {dictionary[key]:.2f}F")


if f_or_c.lower() == 'c':
    c = calculate_f(temp)
    wind_chill = calculate_wind_chill(c)
else:
    wind_chill = calculate_wind_chill(temp)
    
print_f(wind_chill)
